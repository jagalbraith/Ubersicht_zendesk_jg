#!/usr/bin/env python

#We are going to use requests to get the stuff from the webpage.
import requests
import json
import socket

def get_tickets():
    subdomain = 'mysubdomain' #Enter your subdomain
    username = '{email}/token'.format(email='email@domain.com') #Enter your email address
    password = 'xxxxxxxxxxxxxxxxxxxx' #Enter your token ID
    webpage = 'https://{subdomain}.zendesk.com/api/v2/search.json'.format(subdomain=subdomain)

    #Feel free to change up your query. Each param is a dictionary item. key:value
    params = {'query': 'type:ticket status<solved','sort_by': 'status','sort_order': 'asc' }

    #run it and return it.
    results = requests.get(webpage, params=params, auth=(username, password))
    return results.json()


#This will give you a JSON object, you're on your own from here.
tickets = get_tickets()
iplist = str([ip for ip in socket.gethostbyname_ex(socket.gethostname())[2] if not ip.startswith("127.")][:1])
relist = []

# EDIT YOUR IP ADDRESS RANGES TO SEPARATE YOUR TICKETS
if '10.5.' in str(iplist):
    location = 'work'
elif '10.1.112.' in str(iplist):
    location = 'home'
else:
    location = 'MOTOFACKO'
#print location, iplist

low = []
normal = []
high = []
urgent = []
otherpri = []

for result in tickets['results']:
    if location in str(result['tags']):
        if 'urgent' in result['priority']:
            pricolor = 'urgent'
        elif 'high' in result['priority']:
            pricolor = 'high'
        elif 'normal' in result['priority']:
            pricolor = 'normal'
        elif 'low' in result['priority']:
            pricolor = 'low'
        tt = {}
        tt['ticket'] = '''
        <tr>
        <td width="20px">&nbsp;</td>
        <td align="left" width="80px" valign="top"><div class="{c}"><em>{pri}<em></div></td>
        <td align="left" width="80px" valign="top"><div class="{c}"><em>{st}</em></div></td>
        <td align="left" valign="top"><div class="{c}"><em>{su}</em></div></td>
        <td width="20px">&nbsp;</td>
        </tr>
        '''.format(su=result['subject'], st=result['status'], pri=result['priority'], c=pricolor)



        if result['priority'] == 'low':
            low.append(tt)
        elif result['priority'] == 'normal':
            normal.append(tt)
        elif result['priority'] == 'high':
            high.append(tt)
        elif result['priority'] == 'urgent':
            urgent.append(tt)
        else:
            otherpri.append(tt)

relist = urgent + high + normal + low + otherpri


print json.dumps(relist)
